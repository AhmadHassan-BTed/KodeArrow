<?php

// Firebase configuration (not used for saving to Firebase in this version)
$firebaseConfig = array(
    'apiKey' => 'AIzaSyAQkoqiC-C_QguqGkxzykJ8hRfx2eCtTWs',
    'authDomain' => 'kodearrow-website.firebaseapp.com',
    'databaseURL' => 'https://kodearrow-website-default-rtdb.firebaseio.com',
    'projectId' => 'kodearrow-website',
    'storageBucket' => 'kodearrow-website.appspot.com',
    'messagingSenderId' => '1076838775827',
    'appId' => '1:1076838775827:web:f7e249864699a6cea893e6',
    'measurementId' => 'G-CCDRFW24ZL'
);

// Ensure POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    exit('Method Not Allowed');
}

// Ensure proper JSON content-type header
if ($_SERVER['CONTENT_TYPE'] !== 'application/json') {
    http_response_code(415); // Unsupported Media Type
    exit('Unsupported Media Type');
}

// Get JSON input data
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, true);

// Validate JSON data
if (empty($input)) {
    http_response_code(400); // Bad Request
    exit('Invalid JSON data');
}

// Extract data from JSON
$fullName = $input['fullName'] ?? '';
$phoneNo = $input['phoneNo'] ?? '';
$email = $input['email'] ?? '';
$bank = $input['bank'] ?? '';
$accountNumber = $input['accountNumber'] ?? '';

// Simulate saving to Firebase (replace with actual Firebase integration)
// Example: Saving to Firebase Realtime Database
// Initialize Firebase (adjust this part according to your Firebase setup)
require __DIR__.'/vendor/autoload.php'; // Adjust path as needed

use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;

$serviceAccount = ServiceAccount::fromArray($firebaseConfig);
$firebase = (new Factory)
    ->withServiceAccount($serviceAccount)
    ->create();

$database = $firebase->getDatabase();

// Save data to Firebase
$reference = $database->getReference('payments')->push([
    'Fullname' => $fullName,
    'Phone_number' => $phoneNo,
    'Email' => $email,
    'Bank' => $bank,
    'Account_Number' => $accountNumber,
    'Date' => date('Y-m-d H:i:s') // Example: Timestamp
]);

// Check if data was saved (replace with actual error handling and success checks)
if ($reference->getKey()) {
    // Prepare data for download
    $dataForDownload = [
        'status' => 'success',
        'message' => 'Data saved successfully',
        'fullName' => $fullName,
        'phoneNo' => $phoneNo,
        'email' => $email,
        'bank' => $bank,
        'accountNumber' => $accountNumber
    ];

    // Output JSON data for download
    echo json_encode($dataForDownload);
} else {
    http_response_code(500); // Internal Server Error
    exit('Failed to save data');
}
?>