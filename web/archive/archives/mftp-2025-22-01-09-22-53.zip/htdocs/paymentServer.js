document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('myForm').addEventListener('submit', submitForm);

  function submitForm(e) {
    e.preventDefault();
    var fullName = getInputVal('fullName');
    var phoneNo = getInputVal('phoneNo');
    var email = getInputVal('email');
    var bank = getInputVal('bank');
    var accountNumber = getInputVal('accountNumber');
    
    var formData = {
      fullName: fullName,
      phoneNo: phoneNo,
      email: email,
      bank: bank,
      accountNumber: accountNumber
    };

    // Send POST request to your server
    fetch('https://kodearrow-website.firebaseapp.com/submitForm', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
      console.log('Success:', data);
      // Optionally handle success response on the client side
      // For example, show a success message to the user
      alert('Form submitted successfully!');
    })
    .catch((error) => {
      console.error('Error:', error);
      // Optionally handle error on the client side
      // For example, show an error message to the user
      alert('There was an error submitting the form. Please try again.');
    });
  }

  function getInputVal(id) {
    return document.getElementById(id).value;
  }
});