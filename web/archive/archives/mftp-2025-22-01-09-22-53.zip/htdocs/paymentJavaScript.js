document.addEventListener('keydown', event => {
  if (event.keyCode === 123 || (event.ctrlKey && event.shiftKey && event.keyCode === 73)) {
    event.preventDefault();
  }
});

document.addEventListener('DOMContentLoaded', function () {
  var firebaseConfig = {
    apiKey: "AIzaSyAQkoqiC-C_QguqGkxzykJ8hRfx2eCtTWs",
    authDomain: "kodearrow-website.firebaseapp.com",
    databaseURL: "https://kodearrow-website-default-rtdb.firebaseio.com",
    projectId: "kodearrow-website",
    storageBucket: "kodearrow-website.appspot.com",
    messagingSenderId: "1076838775827",
    appId: "1:1076838775827:web:f7e249864699a6cea893e6",
    measurementId: "G-CCDRFW24ZL"
};

firebase.initializeApp(firebaseConfig);

var messagesRef = firebase.database().ref();

document.getElementById('myForm').addEventListener('submit', submitForm);

function submitForm(e) {
  e.preventDefault();
  var fullName = getInputVal('fullName');
  var phoneNo = getInputVal('phoneNo');
  var email = getInputVal('email');
  var bank = getInputVal('bank');
  var accountNumber = getInputVal('accountNumber');
  var currentDate = new Date();
  var date = currentDate.toLocaleDateString();
  var time = currentDate.toLocaleTimeString();
  var title = `${email.replace(/[^\w\s]/gi, '')}|${date.replace(/\//g, '-')}|${time.replace(/:/g, '-')}`; // Create title based on email, date, and time
  saveMessage(title, fullName, phoneNo, email, bank, date, time, accountNumber);
    // Resetting the form without clearing fields
    // document.getElementById('myForm').reset();
}

function getInputVal(id) {
    return document.getElementById(id).value;
}

function saveMessage(title, fullName, phoneNo, email, bank, date, time, accountNumber) {
  var newMessageRef = messagesRef.child(title); // Use the custom title as the reference key
  newMessageRef.set({
    Fullname: fullName,
    Phone_number: phoneNo,
    Email: email,
    Bank: bank,
    Date: date,
    Time: time,
    Account_Number: accountNumber
    });
   // Optional: Call the tick function for styling adjustments
  tick();
}

const fileInput = document.getElementById('uploadScreenshot');
const label = fileInput.parentElement;

fileInput.addEventListener('change', updateLabel);

function updateLabel() {
    const file = fileInput.files[0];
    if (file) {
      label.innerText = 'Uploaded';
    } else {
      label.innerText = 'Choose File';
    }
}

function tick() {
    const section2 = document.querySelector('.reciptpaper2-icon');
    const payback = document.querySelector('.payback');
    const submitButton = document.querySelector('.submitButton');
    // Check the viewport width
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth;
    
    setTimeout(function() {
      if (viewportWidth > 600) {
        section2.style.marginTop = '3vw';
        payback.style.marginTop = '4vw';
        submitButton.style.marginTop = '3.2vw';
        submitButton.style.letterSpacing = '0.01vw';
        document.getElementById('drawButton').value = 'Checked Out';
      } else {
        section2.style.marginTop = '10vw';
        payback.style.marginTop = '14vw';
        submitButton.style.marginTop = '12vw';
      }
    }, 0); // Adjust timing as needed
  }

  document.querySelector('form').addEventListener('submit', function() {
    document.getElementById('drawButton').classList.add('clicked');
  });
});
