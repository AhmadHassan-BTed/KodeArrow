# KodeArrow

Home-row navigation hotkeys for Arch Linux / KDE Plasma, via `keyd`.

## Files

- **kodearrow** - installs `keyd`, writes the hotkey config, enables the service.
- **kodearrow.conf** - plain copy of that config, for reading before you run anything as root.
- **kodearrow-tray.py** - optional system tray icon (status + GitHub link + Exit).
- **logo.png** - tray icon image. Keep it next to `kodearrow-tray.py`.

## 1. Install the hotkeys

```
chmod +x kodearrow
sudo ./kodearrow
```

Undo any time with `sudo ./kodearrow --remove`.

## 2. (Optional) Add the tray icon

```
sudo pacman -S pyside6
python3 kodearrow-tray.py
```

Make it start on login:

```
python3 kodearrow-tray.py --install-autostart
```

Undo with `python3 kodearrow-tray.py --remove-autostart`.

Note: the tray icon's Exit only closes the tray icon itself. The hotkeys
run as a separate system service (`keyd`) and keep working regardless -
use `sudo ./kodearrow --remove` to actually turn them off.

## The mapping

| Alt + | Action |
|---|---|
| i / j / k / l | Up / Left / Down / Right |
| u / o | Home / End |
| p / ; | Delete / Backspace |
| [ / ' | Page Up / Page Down |

| Ctrl+Alt + | Action |
|---|---|
| u/i/o/j/k/l | Ctrl+Shift+Home/Up/End/Left/Down/Right (select) |
| p / ; | Ctrl+Delete / Ctrl+Backspace (delete word) |

Heads-up: Ctrl+Alt+L is KDE's default "Lock Session" shortcut on many
installs, and is reassigned here. Rebind lock-screen in System Settings
-> Shortcuts -> System Services if you use it (Meta+L is untouched).

GitHub: https://github.com/AhmadHassan-BTed/KodeArrow
