#!/usr/bin/env python3
"""
kodearrow-tray.py — a minimal system tray icon for KodeArrow.

This is only a status + shortcut icon. The navigation hotkeys themselves
are handled system-wide by the keyd service that the `kodearrow` script
installs, and they keep working whether or not this tray icon is running.
All this adds is:
  - a tray icon so you can see KodeArrow is set up
  - a menu item linking to the GitHub repo
  - an Exit item to close the tray icon

Requires PySide6:
  sudo pacman -S pyside6

Run it:
  python3 kodearrow-tray.py

Start it automatically on login (KDE's own XDG autostart mechanism):
  python3 kodearrow-tray.py --install-autostart
  python3 kodearrow-tray.py --remove-autostart   # to undo

logo.png must sit next to this file.
"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPT_PATH = Path(__file__).resolve()
ICON_PATH = HERE / "logo.png"
GITHUB_URL = "https://github.com/AhmadHassan-BTed/KodeArrow"
AUTOSTART_FILE = Path.home() / ".config" / "autostart" / "kodearrow-tray.desktop"


def install_autostart() -> None:
    AUTOSTART_FILE.parent.mkdir(parents=True, exist_ok=True)
    AUTOSTART_FILE.write_text(
        "[Desktop Entry]\n"
        "Type=Application\n"
        "Name=KodeArrow Tray\n"
        f"Exec=python3 {SCRIPT_PATH}\n"
        f"Icon={ICON_PATH}\n"
        "Terminal=false\n"
        "X-GNOME-Autostart-enabled=true\n"
        "Comment=KodeArrow navigation hotkeys tray icon\n"
    )
    print(f"Autostart entry written: {AUTOSTART_FILE}")
    print("KodeArrow's tray icon will now start automatically next time you log in.")


def remove_autostart() -> None:
    if AUTOSTART_FILE.exists():
        AUTOSTART_FILE.unlink()
        print(f"Removed {AUTOSTART_FILE}")
    else:
        print("No autostart entry found - nothing to remove.")


def run_tray() -> None:
    from PySide6.QtCore import QUrl
    from PySide6.QtGui import QAction, QDesktopServices, QIcon
    from PySide6.QtWidgets import QApplication, QMenu, QStyle, QSystemTrayIcon

    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)

    if not QSystemTrayIcon.isSystemTrayAvailable():
        print("No system tray detected in this session.", file=sys.stderr)
        sys.exit(1)

    if ICON_PATH.exists():
        icon = QIcon(str(ICON_PATH))
    else:
        print(f"Warning: {ICON_PATH} not found, using a placeholder icon.", file=sys.stderr)
        icon = app.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)

    tray = QSystemTrayIcon(icon)
    tray.setToolTip("KodeArrow \u2014 navigation hotkeys active")

    menu = QMenu()

    visit_action = QAction("Visit / Contribute on GitHub", menu)
    visit_action.triggered.connect(lambda: QDesktopServices.openUrl(QUrl(GITHUB_URL)))
    menu.addAction(visit_action)

    menu.addSeparator()

    def do_exit() -> None:
        tray.hide()
        app.quit()

    exit_action = QAction("Exit", menu)
    exit_action.triggered.connect(do_exit)
    menu.addAction(exit_action)

    tray.setContextMenu(menu)
    tray.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    if "--install-autostart" in sys.argv:
        install_autostart()
    elif "--remove-autostart" in sys.argv:
        remove_autostart()
    else:
        run_tray()
